<?php
  echo '<form>
  <input type="text" id="idadd" placeholder="id">
  <input type="text" id="nameadd" placeholder="name" >
  <input type="text" id="yearadd" placeholder="year" >
  <input type="button" name="submit" id="submit5" value="submitAdd" class="btn btn-primary" onclick="submit_addform()">
  </form>';
?>