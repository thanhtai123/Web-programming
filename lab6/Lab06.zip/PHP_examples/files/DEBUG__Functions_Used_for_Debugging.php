<?php
/*
Name                   Description

echo()                 Prints a simple variable or value

print()                Prints a simple variable or value

printf()               Prints a formatted string

var_dump()             Prints the type and content of a variable

print_r()              Recursively prints the content of an array or object

debug_backtrace()      Returns an array with the call stack and other values
*/

?>
<?php

$a = array('orange', 'apple');
var_dump($a);
?>